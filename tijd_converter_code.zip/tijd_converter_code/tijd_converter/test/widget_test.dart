// widget_test.dart
//
// Hier testen we de schermen (de UI) automatisch.
// Draai met:  flutter test
//
// De import gebruikt de projectnaam 'keuzedeel3_mad' (zie pubspec.yaml).

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:keuzedeel3_mad/main.dart';

void main() {
  testWidgets('App start en toont de titel en de drie tabbladen',
          (WidgetTester tester) async {
        await tester.pumpWidget(const TijdConverterApp());

        // De titel staat bovenaan in de AppBar.
        expect(find.text('Tijdseenheden Converter'), findsOneWidget);

        // De drie navigatieknoppen onderaan bestaan.
        expect(find.text('Invoer'), findsOneWidget);
        expect(find.text('Overzicht'), findsOneWidget);
        expect(find.text('Instellingen'), findsOneWidget);
      });

  testWidgets('60 minuten invoeren toont 1 uur als resultaat',
          (WidgetTester tester) async {
        await tester.pumpWidget(const TijdConverterApp());

        // Typ 60 in het invoerveld (standaard-eenheid is Minuten).
        await tester.enterText(find.byType(TextField), '60');
        await tester.pump();

        // 60 minuten = 1 uur, dus dit moet ergens op het scherm staan.
        expect(find.text('Uren: 1'), findsOneWidget);
      });
}