// converter_test.dart
//
// Hierin testen we de reken-logica uit lib/converter.dart.
// Draai de tests met:  flutter test
//
// LET OP: de import hieronder gebruikt de projectnaam 'tijd_converter'.
// Heet jouw project anders (zie de eerste regel 'name:' in pubspec.yaml),
// pas dan de naam in de import hieronder aan.

import 'package:flutter_test/flutter_test.dart';
import 'package:keuzedeel3_mad/converter.dart';

void main() {
  test('1 minuut is 60 seconden', () {
    expect(converteer(1, Tijdseenheid.minuten, Tijdseenheid.seconden), 60);
  });

  test('1 uur is 60 minuten', () {
    expect(converteer(1, Tijdseenheid.uren, Tijdseenheid.minuten), 60);
  });

  test('1 dag is 24 uur', () {
    expect(converteer(1, Tijdseenheid.dagen, Tijdseenheid.uren), 24);
  });

  test('1 dag is 86400 seconden', () {
    expect(converteer(1, Tijdseenheid.dagen, Tijdseenheid.seconden), 86400);
  });

  test('120 seconden is 2 minuten', () {
    expect(converteer(120, Tijdseenheid.seconden, Tijdseenheid.minuten), 2);
  });

  test('dezelfde eenheid geeft dezelfde waarde', () {
    expect(converteer(5, Tijdseenheid.uren, Tijdseenheid.uren), 5);
  });

  test('0 blijft 0', () {
    expect(converteer(0, Tijdseenheid.dagen, Tijdseenheid.seconden), 0);
  });

  test('halve waarde werkt (0.5 dag = 12 uur)', () {
    expect(converteer(0.5, Tijdseenheid.dagen, Tijdseenheid.uren), 12);
  });

  test('netGetal haalt onnodige nullen weg', () {
    expect(netGetal(60.0), '60');
    expect(netGetal(1.5), '1.5');
  });
}
