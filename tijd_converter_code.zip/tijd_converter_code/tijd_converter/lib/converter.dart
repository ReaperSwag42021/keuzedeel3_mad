// converter.dart
//
// Hierin staat alle reken-logica van de app, los van de schermen.
// Door dit apart te zetten kun je het makkelijk testen (zie test/converter_test.dart)
// en blijft de code in de schermen overzichtelijk.

/// De tijdseenheden die de app ondersteunt.
enum Tijdseenheid { seconden, minuten, uren, dagen }

/// Geeft een nette Nederlandse naam terug voor een tijdseenheid.
/// Handig om in de schermen te tonen.
String eenheidNaam(Tijdseenheid eenheid) {
  switch (eenheid) {
    case Tijdseenheid.seconden:
      return 'Seconden';
    case Tijdseenheid.minuten:
      return 'Minuten';
    case Tijdseenheid.uren:
      return 'Uren';
    case Tijdseenheid.dagen:
      return 'Dagen';
  }
}

/// Hoeveel seconden zit er in 1 van deze eenheid.
/// We gebruiken seconden als "tussenstap" voor alle berekeningen.
double secondenPerEenheid(Tijdseenheid eenheid) {
  switch (eenheid) {
    case Tijdseenheid.seconden:
      return 1;
    case Tijdseenheid.minuten:
      return 60;
    case Tijdseenheid.uren:
      return 3600; // 60 * 60
    case Tijdseenheid.dagen:
      return 86400; // 24 * 60 * 60
  }
}

/// Zet een waarde van de ene eenheid om naar de andere.
///
/// De truc: we rekenen altijd eerst alles om naar seconden,
/// en daarna van seconden naar de doel-eenheid. Zo hoeven we
/// niet voor elke combinatie een aparte formule te schrijven.
///
/// Voorbeeld: converteer(1, minuten, seconden)
///   stap 1: 1 minuut * 60 = 60 seconden
///   stap 2: 60 seconden / 1 = 60
double converteer(double waarde, Tijdseenheid van, Tijdseenheid naar) {
  double inSeconden = waarde * secondenPerEenheid(van);
  return inSeconden / secondenPerEenheid(naar);
}

/// Maakt een getal netjes leesbaar (haalt onnodige nullen achter de komma weg).
/// Voorbeeld: 60.0000 wordt "60", en 1.5000 wordt "1.5".
String netGetal(double getal) {
  String tekst = getal.toStringAsFixed(6);
  // Haal nullen aan het eind weg...
  tekst = tekst.replaceAll(RegExp(r'0+$'), '');
  // ...en daarna een eventuele losse punt aan het eind.
  tekst = tekst.replaceAll(RegExp(r'\.$'), '');
  return tekst;
}
