import 'dart:async';
import 'package:flutter/material.dart';
import '../converter.dart';

/// Scherm 2: overzicht van de ingevoerde waarde in alle eenheden.
/// Bovenaan staat een live klok (tijd-thema + bonus: loopt realtime mee).
class OverzichtScherm extends StatefulWidget {
  final double waarde;
  final Tijdseenheid vanEenheid;

  const OverzichtScherm({
    super.key,
    required this.waarde,
    required this.vanEenheid,
  });

  @override
  State<OverzichtScherm> createState() => _OverzichtSchermState();
}

class _OverzichtSchermState extends State<OverzichtScherm> {
  late Timer _timer;
  DateTime _nu = DateTime.now();

  @override
  void initState() {
    super.initState();
    // Elke seconde de klok bijwerken.
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() {
        _nu = DateTime.now();
      });
    });
  }

  @override
  void dispose() {
    _timer.cancel(); // belangrijk: timer stoppen om geheugenlekken te voorkomen
    super.dispose();
  }

  // Maakt van een getal twee cijfers, bijvoorbeeld 9 -> "09".
  String _tweeCijfers(int n) => n.toString().padLeft(2, '0');

  @override
  Widget build(BuildContext context) {
    final klok = '${_tweeCijfers(_nu.hour)}:'
        '${_tweeCijfers(_nu.minute)}:'
        '${_tweeCijfers(_nu.second)}';

    // Bonus: laat zien met hoeveel liedjes (van ~3 minuten) de tijd overeenkomt.
    final seconden =
        converteer(widget.waarde, widget.vanEenheid, Tijdseenheid.seconden);
    final aantalLiedjes = seconden / 180;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Live klok bovenaan.
          Center(
            child: Column(
              children: [
                const Icon(Icons.schedule, size: 48),
                Text(
                  klok,
                  style: const TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Text('Huidige tijd'),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'Jouw invoer: ${netGetal(widget.waarde)} '
            '${eenheidNaam(widget.vanEenheid)}',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          // Tabel met de waarde in alle eenheden.
          Table(
            border: TableBorder.all(color: Colors.grey),
            children: [
              const TableRow(
                children: [
                  Padding(
                    padding: EdgeInsets.all(8),
                    child: Text('Eenheid',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                  Padding(
                    padding: EdgeInsets.all(8),
                    child: Text('Waarde',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
              for (final doel in Tijdseenheid.values)
                TableRow(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8),
                      child: Text(eenheidNaam(doel)),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8),
                      child: Text(netGetal(
                          converteer(widget.waarde, widget.vanEenheid, doel))),
                    ),
                  ],
                ),
            ],
          ),
          const SizedBox(height: 24),
          // Bonus: leuk weetje.
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                'Leuk weetje: dit is ongeveer '
                '${netGetal(aantalLiedjes)} liedje(s) van 3 minuten.',
                style: const TextStyle(fontSize: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
