import 'package:flutter/material.dart';
import '../converter.dart';

/// Scherm 1: hier voert de gebruiker een waarde in en kiest van welke eenheid.
/// Direct eronder tonen we het resultaat in alle eenheden.
class InvoerScherm extends StatefulWidget {
  final double waarde;
  final Tijdseenheid vanEenheid;

  // Functie die we aanroepen als de invoer verandert, zodat de
  // hoofd-app (main.dart) de nieuwe waarde kan bewaren voor het overzicht.
  final void Function(double waarde, Tijdseenheid van) opInvoerVeranderd;

  const InvoerScherm({
    super.key,
    required this.waarde,
    required this.vanEenheid,
    required this.opInvoerVeranderd,
  });

  @override
  State<InvoerScherm> createState() => _InvoerSchermState();
}

class _InvoerSchermState extends State<InvoerScherm> {
  // Controller om de tekst in het invoerveld uit te lezen.
  final TextEditingController _controller = TextEditingController();
  late Tijdseenheid _gekozenEenheid;

  @override
  void initState() {
    super.initState();
    _gekozenEenheid = widget.vanEenheid;
    if (widget.waarde != 0) {
      _controller.text = netGetal(widget.waarde);
    }
  }

  @override
  void dispose() {
    _controller.dispose(); // controller opruimen om geheugenlekken te voorkomen
    super.dispose();
  }

  // Leest het invoerveld uit en geeft de waarde door aan de hoofd-app.
  void _verwerkInvoer() {
    // Komma vervangen door punt, zodat bijvoorbeeld "1,5" ook werkt.
    final tekst = _controller.text.replaceAll(',', '.');
    // double.tryParse geeft null bij onzin-invoer; dan gebruiken we 0.
    final waarde = double.tryParse(tekst) ?? 0;
    widget.opInvoerVeranderd(waarde, _gekozenEenheid);
  }

  @override
  Widget build(BuildContext context) {
    // Bereken de huidige waarde alvast om het resultaat te kunnen tonen.
    final tekst = _controller.text.replaceAll(',', '.');
    final waarde = double.tryParse(tekst) ?? 0;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Center(child: Icon(Icons.access_time, size: 64)),
          const SizedBox(height: 16),
          const Text(
            'Voer een tijd in en kies de eenheid:',
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _controller,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: 'Waarde',
              border: OutlineInputBorder(),
            ),
            // Bij elke wijziging het resultaat opnieuw berekenen en doorgeven.
            onChanged: (_) {
              setState(_verwerkInvoer);
            },
          ),
          const SizedBox(height: 16),
          DropdownButton<Tijdseenheid>(
            value: _gekozenEenheid,
            isExpanded: true,
            items: Tijdseenheid.values.map((eenheid) {
              return DropdownMenuItem(
                value: eenheid,
                child: Text(eenheidNaam(eenheid)),
              );
            }).toList(),
            onChanged: (nieuweEenheid) {
              if (nieuweEenheid != null) {
                setState(() {
                  _gekozenEenheid = nieuweEenheid;
                });
                _verwerkInvoer();
              }
            },
          ),
          const SizedBox(height: 24),
          const Text(
            'Resultaat:',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          // Toon de ingevoerde waarde omgezet naar elke eenheid.
          for (final doel in Tijdseenheid.values)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Text(
                '${eenheidNaam(doel)}: '
                '${netGetal(converteer(waarde, _gekozenEenheid, doel))}',
                style: const TextStyle(fontSize: 16),
              ),
            ),
        ],
      ),
    );
  }
}
