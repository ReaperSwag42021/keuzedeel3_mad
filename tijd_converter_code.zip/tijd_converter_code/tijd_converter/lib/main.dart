import 'package:flutter/material.dart';
import 'converter.dart';
import 'schermen/invoer_scherm.dart';
import 'schermen/overzicht_scherm.dart';
import 'schermen/instellingen_scherm.dart';

void main() {
  runApp(const TijdConverterApp());
}

/// De hoofd-widget van de app.
///
/// Deze is "stateful" omdat we hier de gegevens bewaren die op meerdere
/// schermen nodig zijn: de donkere modus (instellingen + thema) en de
/// ingevoerde waarde (invoer + overzicht). We geven die gegevens door
/// aan de schermen, en de schermen geven via functies wijzigingen terug.
class TijdConverterApp extends StatefulWidget {
  const TijdConverterApp({super.key});

  @override
  State<TijdConverterApp> createState() => _TijdConverterAppState();
}

class _TijdConverterAppState extends State<TijdConverterApp> {
  // Gedeelde gegevens voor de hele app:
  bool _donkereModus = false;
  double _waarde = 0;
  Tijdseenheid _vanEenheid = Tijdseenheid.minuten;

  // Welk tabblad onderaan gekozen is (0 = invoer, 1 = overzicht, 2 = instellingen).
  int _huidigTabblad = 0;

  // Wordt aangeroepen door het instellingen-scherm.
  void _zetDonkereModus(bool aan) {
    setState(() {
      _donkereModus = aan;
    });
  }

  // Wordt aangeroepen door het invoer-scherm als de invoer verandert.
  void _zetInvoer(double waarde, Tijdseenheid van) {
    setState(() {
      _waarde = waarde;
      _vanEenheid = van;
    });
  }

  @override
  Widget build(BuildContext context) {
    // De drie schermen. We bouwen ze hier zodat we de gedeelde
    // gegevens kunnen meegeven.
    final schermen = [
      InvoerScherm(
        waarde: _waarde,
        vanEenheid: _vanEenheid,
        opInvoerVeranderd: _zetInvoer,
      ),
      OverzichtScherm(
        waarde: _waarde,
        vanEenheid: _vanEenheid,
      ),
      InstellingenScherm(
        donkereModus: _donkereModus,
        opDonkereModusVeranderd: _zetDonkereModus,
      ),
    ];

    return MaterialApp(
      title: 'Tijdseenheden Converter',
      debugShowCheckedModeBanner: false,
      // Een licht en een donker thema. De toggle bepaalt welke we tonen.
      theme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        brightness: Brightness.light,
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      themeMode: _donkereModus ? ThemeMode.dark : ThemeMode.light,
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Tijdseenheden Converter'),
        ),
        // IndexedStack houdt de schermen "in leven" als je wisselt,
        // zodat je ingevoerde waarde niet verdwijnt.
        body: IndexedStack(
          index: _huidigTabblad,
          children: schermen,
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _huidigTabblad,
          onDestinationSelected: (index) {
            setState(() {
              _huidigTabblad = index;
            });
          },
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.edit),
              label: 'Invoer',
            ),
            NavigationDestination(
              icon: Icon(Icons.list),
              label: 'Overzicht',
            ),
            NavigationDestination(
              icon: Icon(Icons.settings),
              label: 'Instellingen',
            ),
          ],
        ),
      ),
    );
  }
}
