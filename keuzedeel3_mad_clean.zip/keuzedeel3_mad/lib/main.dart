import 'package:flutter/material.dart';
import 'converter.dart';
import 'schermen/invoer_scherm.dart';
import 'schermen/overzicht_scherm.dart';
import 'schermen/instellingen_scherm.dart';

void main() {
  runApp(const TijdConverterApp());
}

/// De donkere modus (instellingen + thema) en de
/// ingevoerde waarde (invoer + overzicht). We geven die gegevens door
/// aan de schermen, en de schermen geven via functies wijzigingen terug.
class TijdConverterApp extends StatefulWidget {
  const TijdConverterApp({super.key});

  @override
  State<TijdConverterApp> createState() => _TijdConverterAppState();
}

class _TijdConverterAppState extends State<TijdConverterApp> {
  // Gedeelde gegevens voor de hele app:
  bool _donkereModus = false;
  double _waarde = 0;
  Tijdseenheid _vanEenheid = Tijdseenheid.minuten;

  // Welk tabblad gekozen (0 = invoer, 1 = overzicht, 2 = instellingen).
  int _huidigTabblad = 0;

  // Wordt aangeroepen instellingen-scherm.
  void _zetDonkereModus(bool aan) {
    setState(() {
      _donkereModus = aan;
    });
  }

  // Wordt aangeroepen door invoer-scherm als invoer verandert.
  void _zetInvoer(double waarde, Tijdseenheid van) {
    setState(() {
      _waarde = waarde;
      _vanEenheid = van;
    });
  }

  @override
  Widget build(BuildContext context) {
    // De drie schermen.
    final schermen = [
      InvoerScherm(
        waarde: _waarde,
        vanEenheid: _vanEenheid,
        opInvoerVeranderd: _zetInvoer,
      ),
      OverzichtScherm(
        waarde: _waarde,
        vanEenheid: _vanEenheid,
      ),
      InstellingenScherm(
        donkereModus: _donkereModus,
        opDonkereModusVeranderd: _zetDonkereModus,
      ),
    ];

    return MaterialApp(
      title: 'Tijdseenheden Converter',
      debugShowCheckedModeBanner: false,
      // De kleuren passen bij de modus:
      // - lichte modus: warme, zonnige kleuren (amber/geel)
      // - donkere modus: donkere kleuren (donkerblauw/indigo)
      theme: ThemeData(
        colorSchemeSeed: Colors.amber, // zon-kleur, lichte modus
        brightness: Brightness.light,
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        colorSchemeSeed: Colors.indigo, // donkerblauw, donkere modus
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      themeMode: _donkereModus ? ThemeMode.dark : ThemeMode.light,
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Tijdseenheden Converter'),
        ),
        // IndexedStack houdt schermen "in leven" als je wisselt,
        // zodat je ingevoerde waarde niet verdwijnt.
        body: IndexedStack(
          index: _huidigTabblad,
          children: schermen,
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _huidigTabblad,
          onDestinationSelected: (index) {
            setState(() {
              _huidigTabblad = index;
            });
          },
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.edit),
              label: 'Invoer',
            ),
            NavigationDestination(
              icon: Icon(Icons.list),
              label: 'Overzicht',
            ),
            NavigationDestination(
              icon: Icon(Icons.settings),
              label: 'Instellingen',
            ),
          ],
        ),
      ),
    );
  }
}