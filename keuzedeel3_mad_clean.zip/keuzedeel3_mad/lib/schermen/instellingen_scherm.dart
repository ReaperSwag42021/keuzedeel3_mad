import 'package:flutter/material.dart';

/// Scherm 3: Hier kan de gebruiker de donkere modus aan/uit zetten.
class InstellingenScherm extends StatelessWidget {
  final bool donkereModus;
  final void Function(bool aan) opDonkereModusVeranderd;

  const InstellingenScherm({
    super.key,
    required this.donkereModus,
    required this.opDonkereModusVeranderd,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Instellingen',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          SwitchListTile(
            title: const Text('Donkere modus'),
            subtitle: const Text('Schakel tussen het lichte en donkere thema'),
            value: donkereModus,
            onChanged: opDonkereModusVeranderd,
            secondary: const Icon(Icons.dark_mode),
          ),
          const Divider(),
          const ListTile(
            leading: Icon(Icons.info_outline),
            title: Text('Over deze app'),
            subtitle: Text(
              'Tijdseenheden Converter\n'
              'Keuzedeel Mobile Application Development\n'
              'Gemaakt met Flutter en Dart',
            ),
          ),
        ],
      ),
    );
  }
}