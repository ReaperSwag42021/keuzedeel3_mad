// widget_test.dart
//
// Hier testen we de schermen (de UI) automatisch.
// Draai met:  flutter test

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:keuzedeel3_mad/main.dart';

void main() {
  testWidgets('App start en toont de titel en de drie tabbladen',
          (WidgetTester tester) async {
        await tester.pumpWidget(const TijdConverterApp());

        expect(find.text('Tijdseenheden Converter'), findsOneWidget);

        expect(find.text('Invoer'), findsOneWidget);
        expect(find.text('Overzicht'), findsOneWidget);
        expect(find.text('Instellingen'), findsOneWidget);
      });

  testWidgets('60 minuten invoeren toont 1 uur als resultaat',
          (WidgetTester tester) async {
        await tester.pumpWidget(const TijdConverterApp());

        await tester.enterText(find.byType(TextField), '60');
        await tester.pump();

        expect(find.text('Uren: 1'), findsOneWidget);
      });
}